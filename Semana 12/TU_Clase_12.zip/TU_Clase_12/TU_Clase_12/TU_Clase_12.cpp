#include "Curso.h"

int main(){
    Curso obj = Curso("Funda");
    obj.agregarEstudiantes();
    return 0;
}