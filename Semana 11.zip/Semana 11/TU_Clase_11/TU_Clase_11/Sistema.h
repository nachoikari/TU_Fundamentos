#pragma once
#include "Auto.h"
class Sistema{
private:
	Auto autos[100];
};

